Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Partial Class pembayaran_pembayaranNewI
    Inherits System.Web.UI.Page


#Region "Variables Declaration"
    Protected opClass As SQLOperation
    Protected opClass1 As SQLOperation
    Protected opClass2 As SQLOperation
    Protected opClass3 As SQLOperation
    Dim SQLReader As System.Data.SqlClient.SqlDataReader
    Dim SQLReader1 As System.Data.SqlClient.SqlDataReader
    Dim SQLReader2 As System.Data.SqlClient.SqlDataReader
    Dim DepositSemasa As Decimal
    Dim total_caj_kredit As Decimal
    Dim total_caj_agen As Decimal
    Dim stmt As String = ""
    Dim NoSiriResit As String = ""
    Dim Baki_Semasa As Decimal
    Dim DepositSkrg As Decimal
    Dim byrIkan As String = ""
    Dim byrBorang As String = ""
    Public filetransfer As String = ""
    Public transaksi_semasa As Decimal
    Public iResitG1a As ReportDocument
    Public iResitG1aSalinan As ReportDocument


#End Region


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        opClass = New SQLOperation()
        opClass.dbConnection()

        opClass1 = New SQLOperation()
        opClass1.dbConnection()

        opClass2 = New SQLOperation()
        opClass2.dbConnection()

        Dim cajBorang1 As String = ""
        Dim cajEpermit As String = ""

        Dim tabletitle As String = ""
        Dim tabletitle1 As String = ""

        Dim textfield As String = ""
        Dim title As String = ""

        'import table
        tabletitle = "ITEM_ISYTIHAR_I"
        tabletitle1 = "PENGISYTIHARAN_I"
        textfield = "No_SKPI"
        title = "import"

        Response.AddHeader("Refresh", Convert.ToString((Session.Timeout * 60) + 5))

        Try
            If Session("username").ToString() Is Nothing Then

                Session.Clear()
                Dim popupScript As String = "<script language='javascript'>" & _
                "alert('Sessi penggunaan anda telah tamat !!!');parent.location.href='../index.aspx';" & _
                "</script>"
                Response.Write(popupScript)
                Response.End()

            End If
        Catch ex As Exception
            Dim popupScript As String = "<script language='javascript'>" & _
            "alert('Sessi penggunaan anda telah tamat !!!');parent.location.href='../index.aspx';" & _
            "</script>"
            Response.Write(popupScript)
            Response.End()

        End Try

        ' view information

        txtCek.Attributes.Add("onKeyPress", "return keyToUpperCase(this, event);")

        txtRujukan.Text = Trim(Request("strBarcode"))
        lblnokenderaan.Text = Trim(Request("no_kenderaan"))
        Kod_Agen.Value = Trim(Request("Kod_Agen"))
        Urusan.Value = Trim(Request("urusan"))
        selectpay.Value = Trim(Request("selectpay"))
        Kod_Jenis_Urusan.Value = Trim(Request("Kod_Jenis_Urusan"))

        Dim rstKodagen As String = "select p.Nombor_Siri,p.kod_agen_pengangkutan as kod_agen,a.nama_agen_pengangkutan as nama_agen,a.deposit_semasa as deposit_semasa,a.transaksi_semasa" _
        & " from pendaftaran_pintu p" _
        & " inner join agen_pengangkutan a on p.kod_agen_pengangkutan=a.kod_agen_pengangkutan" _
        & " where p.nombor_barcode='" & Trim(txtRujukan.Text) & "'"
        SQLReader = opClass.DataReader(rstKodagen)

        If SQLReader.HasRows Then
            SQLReader.Read()
            DepositSkrg = Trim(SQLReader("deposit_semasa"))
            transaksi_semasa = Trim(SQLReader("transaksi_semasa"))
        End If

        SQLReader.Close()
        SQLReader = Nothing

        ' end coded

        ' untuk cek deposit semasa & jumlah yang ada dengan agen

        Dim cekBayar As String = "Select Kod_Agen_Pengangkutan from pembayaran_caj where Kod_Agen_Pengangkutan = '" & Trim(Kod_Agen.Value) & "' and " _
        & "(DAY(Tarikh_Bayar) = day(getdate())) AND (MONTH(Tarikh_Bayar) = month(getdate())) AND (YEAR(Tarikh_Bayar) = year(getdate()))"
        SQLReader = opClass.DataReader(cekBayar)

        SQLReader.Read()

        If SQLReader.HasRows Then

            total_caj_kredit = CDec(DepositSkrg) - CDec(transaksi_semasa)

        Else

            'Dim myRstQue2 = "SELECT * FROM SISTEM_Q Inner Join pendaftaran_pintu ON pendaftaran_pintu.kod_agen_pengangkutan WHERE No_Barcode = '" & Trim(txtRujukan.Text) & "' and " _
            '& " ((status like '%Pintu Keluar%') OR (status='Pelepasan') or (status='Bayar')) and " _
            '& "(DAY(Tarikh) = day(getdate())) AND (MONTH(Tarikh) = month(getdate())) AND (YEAR(Tarikh) = year(getdate()))"
            'Response.Write(myRstQue2)
            'Response.End()

            Dim myRstQue2 = "select p.kod_agen_pengangkutan as kod_agen" _
            & " from pendaftaran_pintu p" _
            & " inner join sistem_q a on p.nombor_barcode=a.no_barcode" _
            & " WHERE p.kod_agen_pengangkutan = '" & Trim(Kod_Agen.Value) & "'" _
            & " and (DAY(a.Tarikh) = day(getdate())) AND (MONTH(a.Tarikh) = month(getdate())) AND (YEAR(a.Tarikh) = year(getdate()))"
            SQLReader1 = opClass1.DataReader(myRstQue2)

            If Not (SQLReader1.HasRows) Then

                total_caj_kredit = DepositSkrg

                Dim updateU1 As String = "Update AGEN_PENGANGKUTAN set transaksi_semasa ='0' where Kod_Agen_Pengangkutan='" & Trim(Kod_Agen.Value) & "'"
                opClass2.InsertData(updateU1)

            Else

                total_caj_kredit = DepositSkrg - transaksi_semasa
                
            End If

            SQLReader1.Close()
            SQLReader1 = Nothing


        End If

        SQLReader.Close()
        SQLReader = Nothing

        ' display deposit sekarang

        'Response.Write(total_caj_kredit)
        'Response.End()



        If Trim(Request("cara_pembayaran")) = "CEK/TUNAI" Or Trim(Request("cara_pembayaran")) = "CEK" Then

            lbldepositagen.Text = FormatNumber(CDec(total_caj_kredit))

        Else

            lbldepositagen.Text = FormatNumber(CDec(total_caj_kredit))

        End If

        ' end coded

        'view label for type of charge

        Label1.Text = "LKIM Pembayaran Caj Ikan"
        filetransfer = "cetakResit.aspx"

        'end coded


        'checking for print status
        Dim sqlText1 As String = "SELECT print_status from no_siri_resit_lkim where No_barcode = '" & Trim(Request("strBarcode")) & "'"
        SQLReader = opClass1.DataReader(sqlText1)

        SQLReader.Read()

        If Not SQLReader.HasRows Then
            print_status.Value = "N"
        Else
            print_status.Value = "Y"
        End If

        SQLReader.Close()
        SQLReader = Nothing

        ' end coded


        '********* to view information for Caj Perkhidmatan Ikan *********

        Dim viewborangikan As String = ""

        Dim sqlIkan As String = "SELECT sum(TotalCajIkan) as TotalCajIkan From " & Trim(tabletitle1) & " " _
        & " where No_barcode = '" & Trim(Request("strBarcode")) & "' and status='A'"
        SQLReader = opClass.DataReader(sqlIkan)


        Dim countforskpi As Integer = 0
        Dim cajIkan1 As String = ""
        Dim jumlahcajikan As Decimal

        If SQLReader.HasRows Then

            SQLReader.Read()
            jumlahcajikan = CDec(SQLReader("TotalCajIkan"))

        End If

        SQLReader.Close()
        SQLReader = Nothing


        viewborangikan = "Caj Perkhidmatan Ikan" & "`" & (jumlahcajikan) & "`" & "LKIM" & "`" & "PENGISYTIHARAN" & "~"

        '********* end count jumlah ikan and borang ********* 

        '********* Checking for Item Caj ***************************

        arrayVal.Value = viewborangikan

        Dim sqlBorang1 As String = "select * from pembayaran_caj_ikan where No_barcode = '" & Trim(Request("strBarcode")) & "'"
        SQLReader = opClass.DataReader(sqlBorang1)

        If Not SQLReader.HasRows Then

            lblStatusPembayaran.Text = "Belum Jelas"
            cmdResit.Enabled = False
            Button7.Enabled = False

        Else

            itemCek.ReadOnly = True
            itemTunai.ReadOnly = True
            txtCek.ReadOnly = True

            lblStatusPembayaran.Text = "Jelas"
            cmdBayar.Enabled = False
            cmdResit.Enabled = True
            Button7.Enabled = True
            strbuttonL.Enabled = False
            Button3.Disabled = False



            Dim myHost As String
            Dim host As System.Net.IPHostEntry
            host = System.Net.Dns.GetHostEntry(Request.ServerVariables.Item("REMOTE_addr"))
            myHost = host.HostName

            Dim sqlprint As String = "select printer_name from printername where computer_name='" & Trim(myHost) & "'"
            SQLReader1 = opClass1.DataReader(sqlprint)

            If SQLReader1.HasRows Then

                SQLReader1.Read()

                printer_name.Value = SQLReader1("printer_name")

            Else
                printer_name.Value = Replace(printer_name.Value, "/", "\")

            End If

            SQLReader1.Close()
            SQLReader1 = Nothing



        End If

        ' end coded

        SQLReader.Close()
        SQLReader = Nothing


        If Request("cara_pembayaran") = "CEK/TUNAI" Then

            id_tunai.Attributes.Add("style", "DISPLAY:Block")
            id_cek.Attributes.Add("style", "DISPLAY:Block")
            itemTunai.Text = CDec(Trim(Request("itemTunai")))
            itemCek.Text = CDec(Trim(Request("itemCek")))

        End If
        '********* ended program coded ****************************

    End Sub

    Protected Sub cara_pembayaran_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles cara_pembayaran.PreRender
        If Request("cara_pembayaran") <> "" Then
            cara_pembayaran.ClearSelection()
            cara_pembayaran.Items.FindByValue(Request("cara_pembayaran")).Selected = True
        End If
    End Sub

    Protected Sub BAYAR_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdBayar.Click, strbuttonL.Click

        opClass = New SQLOperation()
        opClass.dbConnection()
        opClass2 = New SQLOperation()
        opClass2.dbConnection()
        opClass3 = New SQLOperation()
        opClass3.dbConnection()

        Dim no_cek As String = ""
        Dim cara_bayar As Boolean = False
        Dim strValue = arrayVal.Value
        Dim txtKredit As Decimal

        Dim i As Integer
        Dim rowArray = strValue.Split("~")
        Dim arrBayarCol() As String = rowArray(i).ToString().Split("`")

        If Trim(sender.Id) = "cmdBayar" Or Trim(sender.Id) = "strbuttonL" Then

            ' untuk cek deposit semasa yang untuk yang ada agen dan pembayaran cek

            '' checking selection for cara pembayaran

            If Trim(cara_pembayaran.SelectedValue) = "0" Then

                Response.Write("<script language = javascript>alert('Sila pilih cara untuk pembayaran.');self.location.href='pembayaranNewI.aspx?Kod_Agen=" & Trim(Kod_Agen.Value) & "&no_kenderaan= " & Trim(lblnokenderaan.Text) & "&urusan=" & Trim(Urusan.Value) & "&Kod_Jenis_Urusan=" & Trim(Kod_Jenis_Urusan.Value) & "&strBarcode=" & Trim(txtRujukan.Text) & "';</script>")
                Response.End()

            End If


            If (Trim(cara_pembayaran.SelectedValue) = "CEK" Or Trim(cara_pembayaran.SelectedValue) = "CEK/TUNAI") Or Trim(sender.Id) = "strbuttonL" Then

                
                Dim rstKodagen As String = "select p.Nombor_Siri,p.kod_agen_pengangkutan as kod_agen,a.nama_agen_pengangkutan as nama_agen,a.deposit_semasa as deposit_semasa,a.transaksi_semasa as transaksi_semasa" _
                & " from pendaftaran_pintu p" _
                & " inner join agen_pengangkutan a on p.kod_agen_pengangkutan=a.kod_agen_pengangkutan" _
                & " where p.nombor_barcode='" & Trim(txtRujukan.Text) & "'"
                SQLReader = opClass.DataReader(rstKodagen)

                If SQLReader.HasRows Then

                    SQLReader.Read()
                    NoSiriResit = Trim(SQLReader("Nombor_Siri"))
                    DepositSemasa = Trim(SQLReader("deposit_semasa"))
                    transaksi_semasa = Trim(SQLReader("transaksi_semasa"))

                End If

                SQLReader.Close()
                SQLReader = Nothing

                ' untuk cek deposit semasa,transaksi semasa & jumlah yang ada dengan agen

                Dim cekBayar As String = "Select Kod_Agen_Pengangkutan from pembayaran_caj where Kod_Agen_Pengangkutan = '" & Trim(Kod_Agen.Value) & "' and " _
                & "(DAY(Tarikh_Bayar) = day(getdate())) AND (MONTH(Tarikh_Bayar) = month(getdate())) AND (YEAR(Tarikh_Bayar) = year(getdate()))"
                SQLReader = opClass.DataReader(cekBayar)

                SQLReader.Read()

                If SQLReader.HasRows Then

                    If Trim(cara_pembayaran.SelectedValue) = "CEK" Then

                        total_caj_kredit = CDec(transaksi_semasa) + CDec(arrBayarCol(1))

                    ElseIf Trim(cara_pembayaran.SelectedValue) = "CEK/TUNAI" Then

                        total_caj_kredit = CDec(transaksi_semasa) + CDec(itemCek.Text)

                    End If

                Else

                    Dim cekSystemQ As String = "Select pendaftaran_pintu.Kod_Agen_Pengangkutan from SISTEM_Q Inner join " _
                    & " pendaftaran_pintu ON SISTEM_Q.No_Barcode= pendaftaran_pintu.Nombor_Barcode " _
                    & " where sistem_q.status='Pelepasan' and pendaftaran_pintu.Kod_Agen_Pengangkutan = '" & Kod_Agen.Value & "' and " _
                    & " (DAY(SISTEM_Q.Tarikh) = day(getdate())) AND (MONTH(SISTEM_Q.Tarikh) = month(getdate())) AND " _
                    & " (YEAR(SISTEM_Q.Tarikh) = year(getdate()))"
                    SQLReader2 = opClass3.DataReader(cekSystemQ)

                    If SQLReader2.HasRows Then

                        If Trim(cara_pembayaran.SelectedValue) = "CEK" Then

                            total_caj_kredit = CDec(transaksi_semasa) + CDec(arrBayarCol(1))

                        ElseIf Trim(cara_pembayaran.SelectedValue) = "CEK/TUNAI" Then

                            total_caj_kredit = CDec(transaksi_semasa) + CDec(itemCek.Text)

                        End If

                    Else

                        If Trim(cara_pembayaran.SelectedValue) = "CEK" Then

                            total_caj_kredit = CDec(arrBayarCol(1))

                        ElseIf Trim(cara_pembayaran.SelectedValue) = "CEK/TUNAI" Then

                            total_caj_kredit = CDec(itemCek.Text)

                        End If

                    End If

                    SQLReader2.Close()
                    SQLReader2 = Nothing

                End If


                If Trim(cara_pembayaran.SelectedValue) = "CEK/TUNAI" Then

                    If txtCek.Text = "" Or itemTunai.Text = "" Or itemCek.Text = "" Then

                        Response.Write("<script language = javascript>alert('Sila masukkan data untuk nilai tunai, nilai cek dan juga nombor cek terlebih dahulu.');self.location.href='pembayaranNewI.aspx?Kod_Agen=" & Trim(Kod_Agen.Value) & "&no_kenderaan= " & Trim(lblnokenderaan.Text) & "&urusan=" & Trim(Urusan.Value) & "&Kod_Jenis_Urusan=" & Trim(Kod_Jenis_Urusan.Value) & "&strBarcode=" & Trim(txtRujukan.Text) & "';</script>")
                        Response.End()

                    End If

                    If (CDec(itemTunai.Text) + CDec(itemCek.Text) <> CDec(arrBayarCol(1))) Then

                        Response.Write("<script language = javascript>alert('Jumlah tunai dan cek adalah tidak sama. Sila semak.');self.location.href='pembayaranNewI.aspx?Kod_Agen=" & Trim(Kod_Agen.Value) & "&no_kenderaan= " & Trim(lblnokenderaan.Text) & "&urusan=" & Trim(Urusan.Value) & "&Kod_Jenis_Urusan=" & Trim(Kod_Jenis_Urusan.Value) & "&strBarcode=" & Trim(txtRujukan.Text) & "';</script>")
                        Response.End()

                    End If

                End If


                If (CDec(DepositSemasa) < total_caj_kredit) Then

                    stmt = "Baki deposit semasa anda untuk pembayaran CEK ialah RM " & FormatNumber((lbldepositagen.Text)) & ".Nilai ini tidak mencukupi untuk menjelaskan pembayaran CEK anda !.Anda dikehendaki menjelaskan pembayaran CEK anda dengan CEK dan TUNAI sahaja !"
                    Response.Write("<script languange=javascript>alert( '" & stmt & "');self.location.href='pembayaranNewI.aspx?no_cek=" & no_cek & "&itemTunai=" & itemTunai.Text & "&itemCek=" & itemCek.Text & "&cara_pembayaran=" & Trim(Request("cara_pembayaran")) & "&Kod_Agen=" & Trim(Kod_Agen.Value) & "&no_kenderaan= " & Trim(lblnokenderaan.Text) & "&urusan=" & Trim(Urusan.Value) & "&Kod_Jenis_Urusan=" & Trim(Kod_Jenis_Urusan.Value) & "&strBarcode=" & Trim(txtRujukan.Text) & "'</script>")
                    Response.End()

                Else

                    Dim updateU As String = "Update AGEN_PENGANGKUTAN set transaksi_semasa = '" & Trim(CDec(total_caj_kredit)) & "' WHERE Kod_Agen_Pengangkutan = '" & Trim(Kod_Agen.Value) & "'"
                    opClass2.InsertData(updateU)

                    SQLReader.Close()
                    SQLReader = Nothing

                    '  end coded

                    DepositSemasa = Trim(CDec(DepositSemasa)) - CDec(total_caj_kredit)

                End If

            End If

        End If



        If Trim(sender.Id) = "cmdBayar" Then

            '' checking selection for cara pembayaran

            'If Trim(cara_pembayaran.SelectedValue) = "0" Then

            '    Response.Write("<script language = javascript>alert('Sila pilih cara untuk pembayaran.');self.location.href='pembayaranNewI.aspx?Kod_Agen=" & Trim(Kod_Agen.Value) & "&no_kenderaan= " & Trim(lblnokenderaan.Text) & "&urusan=" & Trim(Urusan.Value) & "&Kod_Jenis_Urusan=" & Trim(Kod_Jenis_Urusan.Value) & "&strBarcode=" & Trim(txtRujukan.Text) & "';</script>")
            '    Response.End()

            'End If

            ' end coded

            ' view invois number from table
            Dim no_invois As Integer

            Dim intInvois As String = "select no_invois from no_invois where no_barcode='" & Trim(txtRujukan.Text) & "'"
            SQLReader = opClass.DataReader(intInvois)

            SQLReader.Read()
            no_invois = SQLReader("no_invois")

            SQLReader.Close()
            SQLReader = Nothing

            '   untuk cek samada boleh pakai cek ataupun tidak

            ' checking for total overall

            'If Trim(cara_pembayaran.SelectedValue) = "CEK/TUNAI" Then

            '    If txtCek.Text = "" Or itemTunai.Text = "" Or itemCek.Text = "" Then

            '        Response.Write("<script language = javascript>alert('Sila masukkan data untuk nilai tunai, nilai cek dan juga nombor cek terlebih dahulu.');self.location.href='pembayaranNewI.aspx?Kod_Agen=" & Trim(Kod_Agen.Value) & "&no_kenderaan= " & Trim(lblnokenderaan.Text) & "&urusan=" & Trim(Urusan.Value) & "&Kod_Jenis_Urusan=" & Trim(Kod_Jenis_Urusan.Value) & "&strBarcode=" & Trim(txtRujukan.Text) & "';</script>")
            '        Response.End()

            '    End If

            ''If (CDec(itemTunai.Text) + CDec(itemCek.Text) <> CDec(arrBayarCol(1))) Then

            ''    Response.Write("<script language = javascript>alert('Jumlah tunai dan cek adalah tidak sama. Sila semak.');self.location.href='pembayaranNewI.aspx?Kod_Agen=" & Trim(Kod_Agen.Value) & "&no_kenderaan= " & Trim(lblnokenderaan.Text) & "&urusan=" & Trim(Urusan.Value) & "&Kod_Jenis_Urusan=" & Trim(Kod_Jenis_Urusan.Value) & "&strBarcode=" & Trim(txtRujukan.Text) & "';</script>")
            ''    Response.End()

            ''End If

            'End If

            ' end coded

            If Trim(cara_pembayaran.SelectedValue) = "CEK" Or Trim(cara_pembayaran.SelectedValue) = "CEK/TUNAI" Then

                If Trim(cara_pembayaran.SelectedValue) = "CEK" Then

                    txtKredit = arrBayarCol(1)

                ElseIf Trim(cara_pembayaran.SelectedValue) = "CEK/TUNAI" Then

                    txtKredit = itemCek.Text

                End If

                'If (CDec(DepositSemasa) = 0) Or (CDec(txtKredit) > CDec(DepositSemasa)) Then

                '    stmt = "Baki deposit semasa anda untuk pembayaran CEK ialah RM " & FormatNumber((DepositSemasa)) & ".Nilai ini tidak mencukupi untuk menjelaskan pembayaran CEK anda !.Anda dikehendaki menjelaskan pembayaran CEK anda dengan CEK dan TUNAI sahaja !"
                '    Response.Write("<script languange=javascript>alert( '" & stmt & "');self.location.href='pembayaranNewI.aspx?no_cek=" & no_cek & "&itemTunai=" & itemTunai.Text & "&itemCek=" & itemCek.Text & "&cara_pembayaran=" & Trim(Request("cara_pembayaran")) & "&Kod_Agen=" & Trim(Kod_Agen.Value) & "&no_kenderaan= " & Trim(lblnokenderaan.Text) & "&urusan=" & Trim(Urusan.Value) & "&Kod_Jenis_Urusan=" & Trim(Kod_Jenis_Urusan.Value) & "&strBarcode=" & Trim(txtRujukan.Text) & "'</script>")
                '    Response.End()

                'End If

                cara_bayar = True

            End If

            '   end coded
            '   to insert the data into the specific table

            Dim ikanvalue As Boolean = False
            Dim bil_item As Integer
            Dim transaksi_semasa As Decimal = 0
            Dim totalTransaksiSemasa As Decimal
            Dim txtTotalCajTunai As Decimal = 0
            Dim txtTotalCajKredit As Decimal = 0

            Call SaveSistemQ()

            Dim intbil As String = "select bil_item from item_caj where no_barcode='" & Trim(txtRujukan.Text) & "' order by bil_item desc"
            SQLReader = opClass.DataReader(intbil)

            SQLReader.Read()
            If SQLReader.HasRows Then
                bil_item = SQLReader("bil_item") + 1
            Else
                bil_item = 1
            End If


            SQLReader.Close()
            SQLReader = Nothing

            If Trim(cara_pembayaran.SelectedValue) = "CEK" Or Trim(cara_pembayaran.SelectedValue) = "TUNAI" Then

                If Trim(cara_pembayaran.SelectedValue) = "CEK" Then

                    no_cek = txtCek.Text

                ElseIf Trim(cara_pembayaran.SelectedValue) = "TUNAI" Then

                    no_cek = "Tiada"

                End If


                Dim sqlText1 As String = "INSERT INTO [W-ICCS].[dbo].[ITEM_CAJ]" _
                & " ([No_Barcode], [Bil_Item], [Kod_Service_Caj], [Nilai_Caj],[Cara_Pembayaran],[No_Cek],[Dicaj_Oleh],[Tempat_Isytihar],[Nama_Pegawai],[No_Pegawai],site_code)" _
                & " VALUES('" & Trim(txtRujukan.Text) & "','" & bil_item & "','" & arrBayarCol(0) & "','" & CDec(arrBayarCol(1)) & "','" & Trim(cara_pembayaran.SelectedValue) & "','" & no_cek & "','" & arrBayarCol(2) & "','" & arrBayarCol(3) & "','" & Session("namaPegawai") & "','" & Session("id_pegawai") & "','" & Right(Trim(txtRujukan.Text), 3) & "')"
                opClass2.InsertData(sqlText1)


            ElseIf Trim(cara_pembayaran.SelectedValue) = "CEK/TUNAI" Then

                no_cek = txtCek.Text

                'bil_item = bil_item + 1

                Dim sqlText1 As String = "INSERT INTO [W-ICCS].[dbo].[ITEM_CAJ]" _
                & " ([No_Barcode], [Bil_Item], [Kod_Service_Caj], [Nilai_Caj],[Cara_Pembayaran],[No_Cek],[Dicaj_Oleh],[Tempat_Isytihar],[Nama_Pegawai],[No_Pegawai],site_code)" _
                & " VALUES('" & Trim(txtRujukan.Text) & "','" & bil_item & "','" & arrBayarCol(0) & "','" & CDec(itemCek.Text) & "','CEK','" & txtCek.Text & "','" & arrBayarCol(2) & "','" & arrBayarCol(3) & "','" & Session("namaPegawai") & "','" & Session("id_pegawai") & "','" & Right(Trim(txtRujukan.Text), 3) & "')"
                opClass2.InsertData(sqlText1)

                bil_item = bil_item + 1

                Dim sqlText2 As String = "INSERT INTO [W-ICCS].[dbo].[ITEM_CAJ]" _
                & " ([No_Barcode], [Bil_Item], [Kod_Service_Caj], [Nilai_Caj],[Cara_Pembayaran],[No_Cek],[Dicaj_Oleh],[Tempat_Isytihar],[Nama_Pegawai],[No_Pegawai],site_code)" _
                & " VALUES('" & Trim(txtRujukan.Text) & "','" & bil_item & "','" & arrBayarCol(0) & "','" & CDec(itemTunai.Text) & "','TUNAI','Tiada','" & arrBayarCol(2) & "','" & arrBayarCol(3) & "','" & Session("namaPegawai") & "','" & Session("id_pegawai") & "','" & Right(Trim(txtRujukan.Text), 3) & "')"
                opClass2.InsertData(sqlText2)

            End If

            Dim strBayar2 = "insert into pembayaran_caj_Ikan(no_barcode,no_invois,siri_module,kod_agen,print_status,site_code) " _
            & "values('" & Trim(txtRujukan.Text) & "','" & Trim(no_invois) & "','individual_receipt','" & Trim(Kod_Agen.Value) & "','0','" & Right(Trim(txtRujukan.Text), 3) & "')"
            opClass2.InsertData(strBayar2)

            totalTransaksiSemasa = totalTransaksiSemasa + CDec(arrBayarCol(1))

            If cara_bayar = True Then

                'Baki_Semasa = CDec(DepositSemasa) - CDec(txtKredit)

                Dim rstLogCek As String = "Select * FROM LOG_TRANSAKSI_DEPOSIT WHERE  No_Barcode = '" & Trim(txtRujukan.Text) & "'"
                SQLReader = opClass.DataReader(rstLogCek)

                ' Simpan Log Transaksi Deposit Bank Yang Menggunakan CEK

                If Not SQLReader.HasRows Then

                    Dim rstLogCekIn1 As String = "Insert Into LOG_TRANSAKSI_DEPOSIT (No_Barcode,No_Siri,Kod_Agen_Pengangkutan," _
                    & "Deposit_Semasa,Transaksi_Deposit,Baki_Semasa,Nama_pegawai," _
                    & "No_Pegawai,site_code) Values ('" & Trim(txtRujukan.Text) & "','" & Trim(NoSiriResit) & "','" & Trim(Kod_Agen.Value) & "','" & Trim(CDec(Replace(lbldepositagen.Text, ",", ""))) & "'," _
                    & "'" & Trim(CDec(txtKredit)) & "','" & Trim(CDec(DepositSemasa)) & "','" & Session("namaPegawai") & "','" & Session("id_pegawai") & "','" & Right(Trim(txtRujukan.Text), 3) & "')"
                    opClass2.InsertData(rstLogCekIn1)

                End If

                SQLReader.Close()
                SQLReader = Nothing

            End If

            ' total caj tunai untuk perkidmatan ikan dan caj borang

            Dim rstCaj As String = "Select sum(nilai_caj) as tunaicaj FROM Item_caj WHERE Cara_Pembayaran='TUNAI' and kod_service_caj='Caj Perkhidmatan Ikan' and No_Barcode = '" & Trim(txtRujukan.Text) & "'"
            SQLReader = opClass.DataReader(rstCaj)

            If SQLReader.HasRows Then
                SQLReader.Read()

                If (SQLReader.IsDBNull(0)) Then
                    txtTotalCajTunai = "0.0"

                Else
                    txtTotalCajTunai = CDec(SQLReader("tunaicaj"))

                End If

            Else

                txtTotalCajTunai = "0.0"

            End If


            SQLReader.Close()
            SQLReader = Nothing

            '  end coded


            '  total caj cek untuk perkidmatan ikan dan caj borang

            Dim rstCaj1 As String = "Select sum(nilai_caj) as cekcaj FROM Item_caj WHERE Cara_Pembayaran='CEK' and kod_service_caj='Caj Perkhidmatan Ikan' and No_Barcode = '" & Trim(txtRujukan.Text) & "'"
            SQLReader = opClass.DataReader(rstCaj1)

            If SQLReader.HasRows Then
                SQLReader.Read()

                If (SQLReader.IsDBNull(0)) Then
                    txtTotalCajKredit = "0.0"

                Else
                    txtTotalCajKredit = CDec(SQLReader("cekcaj"))

                End If

            Else

                txtTotalCajKredit = "0.0"

            End If

            SQLReader.Close()
            SQLReader = Nothing

            totalTransaksiSemasa = CDec(txtTotalCajKredit) + CDec(txtTotalCajTunai)
            '  end coded


            Dim rstPembayaranCaj As String = "Select * FROM PEMBAYARAN_CAJ WHERE  No_Barcode = '" & Trim(txtRujukan.Text) & "'"
            SQLReader = opClass.DataReader(rstPembayaranCaj)


            If Not SQLReader.HasRows Then

                Dim rstPembayaranCaj1 As String = "Insert Into PEMBAYARAN_CAJ (No_Barcode,No_Siri,No_Kenderaan," _
                & "Jumlah_Caj_Tunai,Jumlah_Caj_Kredit,No_Cek,Jumlah_Caj,Kod_Agen_Pengangkutan," _
                & "No_Pegawai,Nama_Pegawai,Status,site_code) Values ('" & Trim(txtRujukan.Text) & "','" & Trim(NoSiriResit) & "','" & Trim(lblnokenderaan.Text) & "'," _
                & "'" & Trim(CDec(txtTotalCajTunai)) & "','" & Trim(CDec(txtTotalCajKredit)) & "','" & Trim(no_cek) & "','" & Trim(CDec(totalTransaksiSemasa)) & "','" & Trim(Kod_Agen.Value) & "'," _
                & "'" & Session("id_pegawai") & "','" & Session("namaPegawai") & "','JELAS','" & Right(Trim(txtRujukan.Text), 3) & "')"
                opClass2.InsertData(rstPembayaranCaj1)

            End If


            SQLReader.Close()
            SQLReader = Nothing

            ' insert for status transaction

            Dim sqlupdate As String = "INSERT INTO IsyProgressStatus_Front([no_rujukan],[no_barcode], [proses], [dateEnter], [entryBy])" & _
            "VALUES('','" & Trim(txtRujukan.Text) & "','PEMBAYARAN CAJ IKAN',getdate(),'" & Session("username") & "')"
            opClass1.InsertData(sqlupdate)

            ' end coded

            Response.Write("<script language = javascript>alert('Maklumat pembayaran untuk caj telah disimpan.');self.location.href='pembayaranNewI.aspx?no_cek=" & no_cek & "&itemTunai=" & itemTunai.Text & "&itemCek=" & itemCek.Text & "&cara_pembayaran=" & Trim(cara_pembayaran.SelectedValue) & "&Kod_Agen=" & Trim(Kod_Agen.Value) & "&no_kenderaan= " & Trim(lblnokenderaan.Text) & "&urusan=" & Trim(Urusan.Value) & "&Kod_Jenis_Urusan=" & Trim(Kod_Jenis_Urusan.Value) & "&strBarcode=" & Trim(txtRujukan.Text) & "';</script>")
            Response.End()

        End If


        If Trim(sender.Id) = "strbuttonL" Then


            If CDec(arrBayarCol(1)) > DepositSemasa Then

                stmt = "Baki deposit semasa anda untuk pembayaran CEK ialah RM " & FormatNumber((DepositSemasa)) & ".Nilai ini tidak mencukupi untuk menjelaskan pembayaran CEK anda !.Anda dikehendaki menjelaskan pembayaran CEK anda dengan CEK dan TUNAI sahaja !"
                Response.Write("<script languange=javascript>alert( '" & stmt & "');self.location.href='pembayaranNewI.aspx?no_cek=" & no_cek & "&itemTunai=" & itemTunai.Text & "&itemCek=" & itemCek.Text & "&cara_pembayaran=" & Trim(Request("cara_pembayaran")) & "&Kod_Agen=" & Trim(Kod_Agen.Value) & "&no_kenderaan= " & Trim(lblnokenderaan.Text) & "&urusan=" & Trim(Urusan.Value) & "&Kod_Jenis_Urusan=" & Trim(Kod_Jenis_Urusan.Value) & "&strBarcode=" & Trim(txtRujukan.Text) & "'</script>")
                Response.End()

            Else


                Dim rstLogCekIn1 As String = "Insert Into LOG_TRANSAKSI_DEPOSIT (No_Barcode,Kod_Agen_Pengangkutan," _
                & "Deposit_Semasa,Transaksi_Deposit,Baki_Semasa,Nama_pegawai," _
                & "No_Pegawai,site_code) Values ('" & Trim(txtRujukan.Text) & "','" & Trim(Kod_Agen.Value) & "','" & Trim(CDec(Replace(lbldepositagen.Text, ",", ""))) & "'," _
                & "'" & Trim(CDec(arrBayarCol(1))) & "','" & Trim(CDec(DepositSemasa)) & "','" & Session("namaPegawai") & "','" & Session("id_pegawai") & "','" & Right(Trim(txtRujukan.Text), 3) & "')"
                opClass2.InsertData(rstLogCekIn1)

                Dim myRstQue1 = "UPDATE SISTEM_Q Set status='Pelepasan',pegawai='" & Session("namaPegawai") & "' WHERE No_Barcode = '" & Trim(txtRujukan.Text) & "'"
                opClass2.InsertData(myRstQue1)

                Response.Write("<script language = javascript>alert('Status pelepasan telah diberikan kepada barcode tersebut.');self.location.href='verifikasi_bayar.aspx?type=ikan';</script>")
                Response.End()

            End If

        End If


    End Sub


    Private Sub SaveSistemQ()

        opClass = New SQLOperation()
        opClass.dbConnection()
        opClass2 = New SQLOperation()
        opClass2.dbConnection()
        Dim status As String = ""


        Dim myRstQue = "SELECT * FROM SISTEM_Q WHERE No_Barcode = '" & Trim(txtRujukan.Text) & "'"
        SQLReader = opClass.DataReader(myRstQue)

        If Not SQLReader.HasRows Then

            Response.Write("<script language=javascript>alert('Sistem-Q tidak dapat mengemaskini status Pembayaran kerana maklumat belum wujud !');self.location.href='verifikasi_bayar.aspx';</script>")
            Response.End()

        Else

            Dim myRstQue1 = "UPDATE SISTEM_Q Set status='Bayar',pegawai='" & Session("namaPegawai") & "' WHERE No_Barcode = '" & Trim(txtRujukan.Text) & "'"
            opClass2.InsertData(myRstQue1)

        End If

        SQLReader.Close()
        SQLReader = Nothing

    End Sub


    Protected Sub Button7_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button7.Click

        Dim siri_module As String = "individual_receipt"
        opClass = New SQLOperation()
        opClass.dbConnection()
        opClass1 = New SQLOperation()
        opClass1.dbConnection()

        Dim SQLReader As System.Data.SqlClient.SqlDataReader
        Dim serial_no As String = ""
        Dim bolPrinted As Boolean = False

        Session.LCID = 2057

        If (sender.id) = "Button7" Then

            If (printer_name.Value) = "" Then
                Response.Write("<script>alert('Sila pilih printer');history.go(-1);</script>")
                Response.End()
            End If


            If print_status.Value <> "Y" And serial_no = "" Then

                Dim rstSerial As String = "insert into serialno_resit_lkim (no_barcode) values ('X');"
                opClass1.InsertData(rstSerial)

                Dim rstSerial1 As String = "select newresit from serialno_resit_lkim  order by newresit desc"
                SQLReader = opClass.DataReader(rstSerial1)

                SQLReader.Read()

                serial_no = SQLReader(0)

                SQLReader.Close()
                SQLReader = Nothing

            End If

            opClass1 = New SQLOperation()
            opClass1.dbConnection()

            opClass2 = New SQLOperation()
            opClass2.dbConnection()
            Dim no_invois As String = ""
            Dim kod_agen As String = ""

            Dim sqlAgen As String = "select kod_agen_pengangkutan from pendaftaran_pintu where nombor_barcode='" & Trim(txtRujukan.Text) & "'"
            SQLReader = opClass.DataReader(sqlAgen)

            SQLReader.Read()

            kod_agen = SQLReader("kod_agen_pengangkutan")

            SQLReader.Close()
            SQLReader = Nothing

            Dim intInvois As String = ""

            intInvois = "select no_invois from no_invois where no_barcode='" & Trim(txtRujukan.Text) & "' order by invois_date desc"
            SQLReader = opClass.DataReader(intInvois)

            SQLReader.Read()

            no_invois = SQLReader("no_invois")

            SQLReader.Close()
            SQLReader = Nothing


            Dim rstemp As String = "select bil_siri,bil_siri_resit from no_siri_resit_lkim where no_barcode = '" & Trim(txtRujukan.Text) & "'"
            SQLReader = opClass.DataReader(rstemp)

            SQLReader.Read()

            If Not SQLReader.HasRows Then

                'end code added

                Dim a As String = "insert into no_siri_resit_lkim(no_barcode,no_invois,bil_siri_resit,siri_module,kod_agen,print_status,site_code) " _
                & " values('" & Trim(txtRujukan.Text) & "','" & Trim(no_invois) & "','" & Trim(serial_no) & "','" & Trim(siri_module) & "','" & Trim(kod_agen) & "','0','" & Right(Trim(txtRujukan.Text), 3) & "')"
                opClass1.InsertData(a)

            Else

                serial_no = SQLReader("bil_siri_resit")

                Dim gconSQL As String = "update pembayaran_caj_ikan set print_status='1' where no_barcode='" & Trim(txtRujukan.Text) & "'"
                opClass1.InsertData(gconSQL)

                Dim gconSQL1 As String = "update no_siri_resit_lkim set print_status='1' where no_barcode='" & Trim(txtRujukan.Text) & "'"
                opClass1.InsertData(gconSQL1)


            End If


            SQLReader.Close()
            SQLReader = Nothing

            Dim rpt As String = ""

            Call ConfigureCrystalReports(serial_no, printer_name.Value)

        End If

    End Sub


    Private Sub ConfigureCrystalReports(ByVal Serial_No As String, ByVal printer_name As String)

        opClass = New SQLOperation()
        opClass.dbConnection()

        Dim cname As String = ""
        Dim cdesc As String = ""
        Dim add1 As String = ""
        Dim add2 As String = ""
        Dim add3 As String = ""
        Dim add4 As String = ""



        Dim myConnectionInfo As ConnectionInfo = New ConnectionInfo()
        myConnectionInfo.DatabaseName = System.Configuration.ConfigurationManager.AppSettings("dbname")
        myConnectionInfo.UserID = System.Configuration.ConfigurationManager.AppSettings("userid")
        myConnectionInfo.Password = System.Configuration.ConfigurationManager.AppSettings("dbpassword")
        myConnectionInfo.ServerName = System.Configuration.ConfigurationManager.AppSettings("servername")

        iResitG1a = New ReportDocument()
        iResitG1aSalinan = New ReportDocument()

        Dim reportPath As String = Server.MapPath("cetakrpt/iResitG1a.rpt")
        Dim reportPath1 As String = Server.MapPath("cetakrpt/iResitG1aSalinan.rpt")

        iResitG1a.Load(reportPath)
        iResitG1aSalinan.Load(reportPath1)


        Dim selectFormula As String = ""

        selectFormula = "{no_siri_resit_lkim.bil_siri_resit} = '" & Trim(Serial_No) & "' AND {ITEM_CAJ.Dicaj_Oleh} = 'LKIM' AND {ITEM_CAJ.Kod_Service_Caj} = 'Caj Perkhidmatan Ikan' AND {PEMBAYARAN_CAJ_IKAN.siri_module}='individual_receipt'"

        Dim sdatetime As String = ""

        Dim sqldate As String = "select getdate() as sdatetime"
        SQLReader = opClass.DataReader(sqldate)

        SQLReader.Read()

        sdatetime = SQLReader("sdatetime")

        SQLReader.Close()
        SQLReader = Nothing

        Dim strSQL As String = "select h.* from iccs_payment_receipt p inner join  iccs_form_header h " _
        & "on p.form_header_id=h.company_code where  p.receipt_id='iResitLKIM'"
        SQLReader = opClass.DataReader(strSQL)

        If SQLReader.HasRows Then
            SQLReader.Read()

            cname = Trim(SQLReader("company_name"))
            cdesc = Trim(SQLReader("company_desc"))
            add1 = Trim(SQLReader("company_add1"))
            add2 = Trim(SQLReader("company_add2"))
            add3 = Trim(SQLReader("company_add3"))
            add4 = Trim(SQLReader("company_add4"))

        End If

        SQLReader.Close()
        SQLReader = Nothing

        iResitG1a.DataDefinition.FormulaFields("company_name").Text = "'" & cname & "'"
        iResitG1a.DataDefinition.FormulaFields("company_desc").Text = "'" & cdesc & "'"
        iResitG1a.DataDefinition.FormulaFields("company_add1").Text = "'" & add1 & "'"
        iResitG1a.DataDefinition.FormulaFields("company_add2").Text = "'" & add2 & "'"
        iResitG1a.DataDefinition.FormulaFields("company_add3").Text = "'" & add3 & "'"
        iResitG1a.DataDefinition.FormulaFields("company_add4").Text = "'" & add4 & "'"
        iResitG1a.DataDefinition.FormulaFields("sdatetime").Text = "'" & sdatetime & "'"


        iResitG1aSalinan.DataDefinition.FormulaFields("company_name").Text = "'" & cname & "'"
        iResitG1aSalinan.DataDefinition.FormulaFields("company_desc").Text = "'" & cdesc & "'"
        iResitG1aSalinan.DataDefinition.FormulaFields("company_add1").Text = "'" & add1 & "'"
        iResitG1aSalinan.DataDefinition.FormulaFields("company_add2").Text = "'" & add2 & "'"
        iResitG1aSalinan.DataDefinition.FormulaFields("company_add3").Text = "'" & add3 & "'"
        iResitG1aSalinan.DataDefinition.FormulaFields("company_add4").Text = "'" & add4 & "'"
        iResitG1aSalinan.DataDefinition.FormulaFields("sdatetime").Text = "'" & sdatetime & "'"


        iResitG1a.DataDefinition.RecordSelectionFormula = selectFormula
        iResitG1aSalinan.DataDefinition.RecordSelectionFormula = selectFormula

        myCrystalReportViewer.ReportSource = iResitG1a
        myCrystalReportViewer1.ReportSource = iResitG1aSalinan

        SetDBLogonForReport(myConnectionInfo, iResitG1a)
        SetDBLogonForReport(myConnectionInfo, iResitG1aSalinan)

        Dim namaPrinter As String = printer_name '"KONICA MINOLTA 7145/IP-432" '
        iResitG1a.PrintOptions.PrinterName = namaPrinter
        iResitG1a.PrintToPrinter(1, False, 0, 0)
        iResitG1aSalinan.PrintOptions.PrinterName = namaPrinter
        iResitG1aSalinan.PrintToPrinter(1, False, 0, 0)

    End Sub


    Private Sub SetDBLogonForReport(ByVal myConnectionInfo As ConnectionInfo, ByVal myReportDocument As ReportDocument)
        Dim myTables As Tables = myReportDocument.Database.Tables
        For Each myTable As CrystalDecisions.CrystalReports.Engine.Table In myTables
            Dim myTableLogonInfo As TableLogOnInfo = myTable.LogOnInfo
            myTableLogonInfo.ConnectionInfo = myConnectionInfo
            myTable.ApplyLogOnInfo(myTableLogonInfo)
        Next
    End Sub


    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        opClass.dbConnection_Close()
    End Sub

End Class
